<?php
$hostname = 'localhost';
$userdb = 'root';
$passdb = '';
$namedb = 'galeriangel';

$koneksi = mysqli_connect($hostname, $userdb, $passdb, $namedb);

?>