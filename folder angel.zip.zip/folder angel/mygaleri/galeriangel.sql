-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 15 Mar 2024 pada 09.07
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `galeriangel`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `album`
--

CREATE TABLE `album` (
  `albumid` int(11) NOT NULL,
  `namaalbum` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `tanggaldibuat` date NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `album`
--

INSERT INTO `album` (`albumid`, `namaalbum`, `deskripsi`, `tanggaldibuat`, `userid`) VALUES
(12, 'BLACKPINK', 'Idol K-pop\r\n                            ', '2024-03-15', 6),
(13, 'ENHYPEN', 'Boyband from South Korea', '2024-02-29', 6),
(14, 'IVE', 'IVE adalah grup idola wanita dari Korea Selatan yang dibentuk oleh Starship Entertainment pada tahun 2021.', '2024-03-05', 6),
(15, 'AKTRIS', 'Aktris wanita korsel', '2024-03-02', 6);

-- --------------------------------------------------------

--
-- Struktur dari tabel `dislikefoto`
--

CREATE TABLE `dislikefoto` (
  `dislikeid` int(11) NOT NULL,
  `fotoid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `tanggallike` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `dislikefoto`
--

INSERT INTO `dislikefoto` (`dislikeid`, `fotoid`, `userid`, `tanggallike`) VALUES
(20, 21, 6, '2024-02-29'),
(22, 20, 6, '2024-03-05'),
(23, 19, 6, '2024-03-05'),
(26, 18, 6, '2024-03-15'),
(27, 17, 6, '2024-03-15');

-- --------------------------------------------------------

--
-- Struktur dari tabel `foto`
--

CREATE TABLE `foto` (
  `fotoid` int(11) NOT NULL,
  `judulfoto` varchar(255) NOT NULL,
  `deskripsifoto` text NOT NULL,
  `tanggalunggah` date NOT NULL,
  `lokasifile` varchar(255) NOT NULL,
  `albumid` int(11) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `foto`
--

INSERT INTO `foto` (`fotoid`, `judulfoto`, `deskripsifoto`, `tanggalunggah`, `lokasifile`, `albumid`, `userid`) VALUES
(17, 'Lisa', 'Lalisa Manoban, atau lebih dikenal dengan nama panggung Lisa Blackpink, adalah seorang penyanyi sekaligus Rapper asal Thailand yang multitalenta.', '2024-03-05', '1483607097-lisa.jpg', 12, 6),
(18, 'Jennie', 'Jennie atau yang memiliki nama lengkap Kim Jennie merupakan salah satu member Blackpink yang sangat populer.', '2024-03-05', '307461015-jeni.jpg', 12, 6),
(19, 'Rose', 'Roséanne Park (lahir 11 Februari 1997), atau dikenal sebagai Rosé adalah penyanyi dan penari berkebangsaan Korea–Selandia Baru.', '2024-03-05', '679256493-js.jpg', 12, 6),
(20, 'Jisoo', 'Jisoo merupakan salah satu penyanyi asal Korea Selatan. Jisoo dengan nama lengkap Kim Jisoo merupakan vokal dan visual utama.', '2024-03-05', '105679537-jiso.jpg', 12, 6),
(21, 'Sunghoon', 'Nama lengkap: Park Sung Hoon  Lahir: Namyangju, 8 Desember 2002  Posisi: visual, lead dancer  Zodiak: Sagitarius  Kewarganegaraan: Korea Selatan', '2024-03-05', '1214722998-shh.jpg', 13, 6),
(22, 'Jay', 'Jay Park adalah penyanyi Korea Selatan-Amerika Serikat yang merupakan anggota dari boy band Enhypen.', '2024-03-05', '1260523071-jay.jpg', 13, 6),
(23, 'Ni-ki', 'Di grup ENHYPEN, Niki adalah member termuda alias maknae.', '2024-03-05', '2088249676-niki.jpg', 13, 6),
(24, 'Gaeul', 'Gaeul adalah anggota tertua dari girl group IVE dan menempati posisi Rapper.', '2024-03-05', '2003352941-gaeul.jpg', 14, 6),
(25, 'Wonyoung', 'Jang Won-young (lahir 31 Agustus 2004) adalah seorang penyanyi, model, dan presenter asal Korea Selatan.', '2024-03-05', '1083284324-wy.jpg', 14, 6),
(26, 'An Yu-jin', 'Ahn Yu Jin merupakan adalah penyanyi terkenal Korea Selatan yang lebih dikenal dengan nama panggung, Yujin IVE.', '2024-03-05', '553324999-yunjin.jpg', 14, 6),
(27, 'LIZ', 'Kim Ji Won atau Liz (lahir 21 November 2004) adalah seorang model dan penyanyi asal Korea Selatan.', '2024-03-05', '69679299-liz.jpg', 14, 6),
(28, 'Go younjung', 'Go Yoon-jung (Korean: 고윤정; lahir 22 April 1996) adalah aktris dan model asal Korea Selatan.\r\n', '2024-03-05', '1570962834-gyj.jpg', 15, 6),
(29, 'Leeseo', 'Salah satu idol K-Pop yang debut di usia muda adalah Leeseo IVE yang sekaligus menjadi maknae di grupnya.', '2024-03-05', '206029349-liso.jpg', 14, 6),
(30, 'IU', 'IU adalah penyanyi solo dan aktris ternama yang berasal dari Korea Selatan.', '2024-03-05', '1445280017-iu.jpg', 15, 6),
(32, 'Suzy', 'aktris', '2024-03-05', '286548367-suzy.jpg', 15, 6),
(33, 'Rei', 'rei ive', '2024-03-05', '1301747594-rei.jpg', 14, 6),
(34, 'Jake', 'Jake merupakan salah satu personel boy band ENHYPEN dan mempunyai nama lengkap Jake Sim dan nama Korea Sim Jae Yun.', '2024-03-05', '1879435177-jke.jpg', 13, 6);

-- --------------------------------------------------------

--
-- Struktur dari tabel `komentarfoto`
--

CREATE TABLE `komentarfoto` (
  `komentarid` int(11) NOT NULL,
  `fotoid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `isikomentar` text NOT NULL,
  `tanggalkomentar` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `komentarfoto`
--

INSERT INTO `komentarfoto` (`komentarid`, `fotoid`, `userid`, `isikomentar`, `tanggalkomentar`) VALUES
(1, 17, 6, 'wah biutipul', '2024-03-05');

-- --------------------------------------------------------

--
-- Struktur dari tabel `likefoto`
--

CREATE TABLE `likefoto` (
  `likeid` int(11) NOT NULL,
  `fotoid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `tanggallike` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `likefoto`
--

INSERT INTO `likefoto` (`likeid`, `fotoid`, `userid`, `tanggallike`) VALUES
(26, 19, 6, '2024-02-28'),
(27, 21, 6, '2024-02-29'),
(29, 33, 6, '2024-03-05'),
(30, 28, 6, '2024-03-06');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `namalengkap` varchar(255) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`userid`, `username`, `password`, `email`, `namalengkap`, `alamat`) VALUES
(6, 'Ryeoun', '4a7d1ed414474e4033ac29ccb8653d9b', 'ry@gmail.com', 'Ryeoun', 'Seoul');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`albumid`),
  ADD KEY `userid` (`userid`);

--
-- Indeks untuk tabel `dislikefoto`
--
ALTER TABLE `dislikefoto`
  ADD PRIMARY KEY (`dislikeid`),
  ADD KEY `fotoid` (`fotoid`),
  ADD KEY `userid` (`userid`);

--
-- Indeks untuk tabel `foto`
--
ALTER TABLE `foto`
  ADD PRIMARY KEY (`fotoid`),
  ADD KEY `albumid` (`albumid`),
  ADD KEY `userid` (`userid`);

--
-- Indeks untuk tabel `komentarfoto`
--
ALTER TABLE `komentarfoto`
  ADD PRIMARY KEY (`komentarid`),
  ADD KEY `fotoid` (`fotoid`),
  ADD KEY `userid` (`userid`);

--
-- Indeks untuk tabel `likefoto`
--
ALTER TABLE `likefoto`
  ADD PRIMARY KEY (`likeid`),
  ADD KEY `fotoid` (`fotoid`),
  ADD KEY `userid` (`userid`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `album`
--
ALTER TABLE `album`
  MODIFY `albumid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `dislikefoto`
--
ALTER TABLE `dislikefoto`
  MODIFY `dislikeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT untuk tabel `foto`
--
ALTER TABLE `foto`
  MODIFY `fotoid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT untuk tabel `komentarfoto`
--
ALTER TABLE `komentarfoto`
  MODIFY `komentarid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `likefoto`
--
ALTER TABLE `likefoto`
  MODIFY `likeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `album`
--
ALTER TABLE `album`
  ADD CONSTRAINT `album_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `foto`
--
ALTER TABLE `foto`
  ADD CONSTRAINT `foto_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `foto_ibfk_2` FOREIGN KEY (`albumid`) REFERENCES `album` (`albumid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `komentarfoto`
--
ALTER TABLE `komentarfoto`
  ADD CONSTRAINT `komentarfoto_ibfk_1` FOREIGN KEY (`fotoid`) REFERENCES `foto` (`fotoid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `komentarfoto_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `likefoto`
--
ALTER TABLE `likefoto`
  ADD CONSTRAINT `likefoto_ibfk_1` FOREIGN KEY (`fotoid`) REFERENCES `foto` (`fotoid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `likefoto_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
